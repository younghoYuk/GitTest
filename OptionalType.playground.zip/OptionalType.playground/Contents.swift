//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//
// [ Optional Type 생성 ]
//
// 변수 타입 이름 뒤에 ? 를 붙인다.
// 변수 선언시 기본적으로 nil 값으 갖게 된다.
var name: String? = "My Name"
var yourName: String? = nil
var tmpName: String?                // nil
var tmpName2: Optional<String>      // nil
var tmpName3 = Optional<String>()   // nil



//
// [ Optional Type 변수값 검사 ]
//
var someValue: Int?

if someValue == nil
{
    someValue = 10
}



//
// [ Optional Type 을 일반 변수 타입으로 변경 ]
//
// i)     Optional Type 에 ! 를 붙여준다.
// ii)    "if let" 을 활용
// iii)   "??" 연산자

// ! 사용
// optional type 의 값이 nil 이 확실히 아닐 경우만 사용
// nil 이면 런타임 오류 발생
let otherValue:Int = someValue!


// if let 뒤에오는 결과값이 nil 이 아닐경우 참
if let value = someValue
{
    print(value)
}

// someValue 값이 nil 이면 0, 그렇지 않으면 someValue 리턴
let intValue: Int = someValue ?? 0


// 
// [ Implicitly Unwrapped Optionals ]
//
// 변수 타입 뒤에 ! 또는 ImplictlyUnwrappedOptional 를 붙인다.
// 기본값은 nil
var implictOptionalValue: Int! = nil
var implictOptionalValue2: Int!
var implictOptionalValue3: ImplicitlyUnwrappedOptional<Int>





